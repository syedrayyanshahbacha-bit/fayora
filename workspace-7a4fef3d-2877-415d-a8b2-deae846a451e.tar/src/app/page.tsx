'use client';

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Instagram, Mail, MapPin } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black via-black/90 to-black"></div>
        
        <div className="relative z-10 container mx-auto px-4 py-20">
          <div className="text-center mb-16">
            <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              FAYORA
            </h1>
            <p className="text-2xl md:text-4xl text-yellow-400 mb-8 font-light tracking-wider">
              Feel Forever
            </p>
            <div className="w-32 h-1 bg-gradient-to-r from-yellow-400 to-yellow-600 mx-auto mb-12"></div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              <Card className="bg-black/80 border-yellow-600/30 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="aspect-square bg-gradient-to-br from-yellow-900/20 to-yellow-600/20 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-16 h-20 bg-gradient-to-b from-gray-800 to-black mx-auto mb-2 rounded-sm border border-yellow-600/30"></div>
                        <p className="text-yellow-400/60 text-xs">Add perfume image here</p>
                        <p className="text-gray-500 text-xs mt-1">1754638506.png</p>
                      </div>
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold text-yellow-400 mb-2">Elegant Design</h3>
                  <p className="text-gray-300">Black bottle with golden accents</p>
                </CardContent>
              </Card>

              <Card className="bg-black/80 border-yellow-600/30 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="aspect-square bg-gradient-to-br from-yellow-900/20 to-yellow-600/20 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-16 h-20 bg-gradient-to-b from-gray-800 to-black mx-auto mb-2 rounded-sm border border-yellow-600/30"></div>
                        <p className="text-yellow-400/60 text-xs">Add perfume image here</p>
                        <p className="text-gray-500 text-xs mt-1">put the perfume in b.png</p>
                      </div>
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold text-yellow-400 mb-2">Luxury Feel</h3>
                  <p className="text-gray-300">Premium fragrance experience</p>
                </CardContent>
              </Card>

              <Card className="bg-black/80 border-yellow-600/30 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="aspect-square bg-gradient-to-br from-yellow-900/20 to-yellow-600/20 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-16 h-20 bg-gradient-to-b from-gray-800 to-black mx-auto mb-2 rounded-sm border border-yellow-600/30"></div>
                        <p className="text-yellow-400/60 text-xs">Add perfume image here</p>
                        <p className="text-gray-500 text-xs mt-1">1754638828.png</p>
                      </div>
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold text-yellow-400 mb-2">Timeless Scent</h3>
                  <p className="text-gray-300">Feel forever with Fayora</p>
                </CardContent>
              </Card>
            </div>
        </div>
      </section>

      {/* Product Showcase */}
      <section className="py-20 bg-gradient-to-b from-black to-yellow-900/10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-bold mb-6 text-yellow-400">
              FAYORA PERFUME
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Experience the essence of luxury with our premium fragrance collection
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="bg-black/60 border-yellow-600/30 backdrop-blur-sm">
              <CardContent className="p-8 md:p-12">
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div className="space-y-6">
                    <div className="aspect-square bg-gradient-to-br from-yellow-900/30 to-yellow-600/30 rounded-lg flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
                        <div className="text-center">
                          <div className="w-20 h-24 bg-gradient-to-b from-gray-800 to-black mx-auto mb-2 rounded-sm border-2 border-yellow-600/50 shadow-lg shadow-yellow-600/20"></div>
                          <p className="text-yellow-400/60 text-sm">Add main perfume image here</p>
                          <p className="text-gray-500 text-xs mt-1">1754638117.png or WhatsApp Image...</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-3xl font-bold text-yellow-400 mb-2">FAYORA</h3>
                      <p className="text-xl text-gray-300 mb-4">Feel Forever</p>
                      <p className="text-gray-400 leading-relaxed">
                        Indulge in the luxurious scent of Fayora, crafted for those who appreciate 
                        the finer things in life. Our signature fragrance combines notes that evoke 
                        elegance, confidence, and timeless beauty.
                      </p>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center gap-4">
                        <span className="text-2xl text-gray-400 line-through">₨3200</span>
                        <Badge className="bg-red-600 text-white text-lg px-4 py-2">
                          Sale Price
                        </Badge>
                        <span className="text-3xl font-bold text-yellow-400">₨2000</span>
                      </div>
                      
                      <Button className="w-full bg-yellow-600 hover:bg-yellow-700 text-black font-bold py-4 text-lg">
                        Order Now
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-8 text-yellow-400">
              ABOUT FAYORA
            </h2>
            <p className="text-xl text-gray-300 leading-relaxed mb-8">
              Fayora represents the pinnacle of fragrance craftsmanship. Each bottle is meticulously 
              designed to deliver an unforgettable sensory experience. Our commitment to quality 
              ensures that every spray of Fayora transports you to a world of elegance and sophistication.
            </p>
            <p className="text-lg text-gray-400 leading-relaxed">
              The black bottle symbolizes mystery and depth, while the golden lettering represents 
              the precious nature of our fragrance. "Feel Forever" isn't just our slogan—it's our 
              promise to you.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gradient-to-b from-black to-yellow-900/10">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-12 text-yellow-400">
              GET IN TOUCH
            </h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="bg-black/60 border-yellow-600/30 backdrop-blur-sm text-center">
                <CardContent className="p-8">
                  <Mail className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-yellow-400 mb-2">Email</h3>
                  <p className="text-gray-300">syedafizza932@gmail.com</p>
                </CardContent>
              </Card>

              <Card className="bg-black/60 border-yellow-600/30 backdrop-blur-sm text-center">
                <CardContent className="p-8">
                  <MapPin className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-yellow-400 mb-2">Location</h3>
                  <p className="text-gray-300">Muryali Dera Ismail Khan<br />Karachi</p>
                </CardContent>
              </Card>

              <Card className="bg-black/60 border-yellow-600/30 backdrop-blur-sm text-center">
                <CardContent className="p-8">
                  <Instagram className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-yellow-400 mb-2">Instagram</h3>
                  <a 
                    href="https://www.instagram.com/biju.diaries" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-gray-300 hover:text-yellow-400 transition-colors"
                  >
                    @biju.diaries
                  </a>
                </CardContent>
              </Card>
            </div>

            <div className="text-center mt-12">
              <p className="text-lg text-gray-400 mb-6">
                Follow us on Instagram for updates and exclusive offers
              </p>
              <Button 
                asChild
                className="bg-gradient-to-r from-yellow-600 to-yellow-700 hover:from-yellow-700 hover:to-yellow-800 text-black font-bold py-3 px-8"
              >
                <a 
                  href="https://www.instagram.com/biju.diaries" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <Instagram className="w-5 h-5" />
                  Follow on Instagram
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-black border-t border-yellow-600/20">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-yellow-400 mb-4">FAYORA</h3>
            <p className="text-lg text-gray-400 mb-6">Feel Forever</p>
            <div className="flex justify-center gap-6 mb-8">
              <a 
                href="https://www.instagram.com/biju.diaries" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-yellow-400 transition-colors"
              >
                <Instagram className="w-6 h-6" />
              </a>
              <a 
                href="mailto:syedafizza932@gmail.com"
                className="text-gray-400 hover:text-yellow-400 transition-colors"
              >
                <Mail className="w-6 h-6" />
              </a>
            </div>
            <p className="text-gray-500">
              © 2024 Fayora. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}