# Fayora Perfume Website - Image Setup Instructions

## Adding Your Perfume Images

Your beautiful Fayora perfume website is ready! To complete it, you need to add your actual perfume images to replace the placeholders.

### Steps to Add Your Images:

1. **Place your images in the public folder:**
   - Copy your perfume images to: `/home/z/my-project/public/`
   - The images you mentioned are:
     - `1754638506.png`
     - `put the perfume in b.png`
     - `1754638828.png`
     - `1754638117.png`
     - `WhatsApp Image 2025-08-08 at 12.15.34_fe70dac3.jpg`

2. **Update the image references in the code:**
   - Open `/home/z/my-project/src/app/page.tsx`
   - Replace the placeholder divs with actual `<img>` tags

### Example Replacement:

**Current placeholder code:**
```jsx
<div className="aspect-square bg-gradient-to-br from-yellow-900/20 to-yellow-600/20 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden">
  <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
    <div className="text-center">
      <div className="w-16 h-20 bg-gradient-to-b from-gray-800 to-black mx-auto mb-2 rounded-sm border border-yellow-600/30"></div>
      <p className="text-yellow-400/60 text-xs">Add perfume image here</p>
      <p className="text-gray-500 text-xs mt-1">1754638506.png</p>
    </div>
  </div>
</div>
```

**Replace with:**
```jsx
<div className="aspect-square rounded-lg mb-4 overflow-hidden">
  <img 
    src="/1754638506.png" 
    alt="Fayora Perfume - Elegant Design" 
    className="w-full h-full object-cover"
  />
</div>
```

### Complete Image Mapping:

1. **Hero Section - First Card:**
   - Image: `1754638506.png`
   - Alt text: "Fayora Perfume - Elegant Design"

2. **Hero Section - Second Card:**
   - Image: `put the perfume in b.png`
   - Alt text: "Fayora Perfume - Luxury Feel"

3. **Hero Section - Third Card:**
   - Image: `1754638828.png`
   - Alt text: "Fayora Perfume - Timeless Scent"

4. **Product Showcase Section:**
   - Image: `1754638117.png` OR `WhatsApp Image 2025-08-08 at 12.15.34_fe70dac3.jpg`
   - Alt text: "Fayora Perfume - Main Product"

### Important Notes:

- Make sure image filenames match exactly (case-sensitive)
- Images should be in web-friendly formats (PNG, JPG, WebP)
- Optimize images for web to ensure fast loading
- The website is already responsive and will handle different image sizes

### Website Features Already Implemented:

✅ **Hero Section** - Stunning introduction with Fayora branding
✅ **Product Showcase** - Displays perfume with pricing (₨3200 → ₨2000 sale)
✅ **About Section** - Brand story and description
✅ **Contact Information** - Email, location, and Instagram links
✅ **Instagram Integration** - Direct link to your Instagram profile
✅ **Black & Gold Theme** - Elegant color scheme throughout
✅ **Responsive Design** - Works on all devices
✅ **Functional Elements** - All buttons and links work properly

### Contact Information Displayed:
- **Email:** syedafizza932@gmail.com
- **Location:** Muryali Dera Ismail Khan Karachi
- **Instagram:** https://www.instagram.com/biju.diaries
- **No phone number** (as requested)

### Pricing Displayed:
- **Original Price:** ₨3200
- **Sale Price:** ₨2000
- **Sale Badge:** Clearly marked

Your website is ready to impress customers with the luxurious Fayora perfume brand! 🖤✨